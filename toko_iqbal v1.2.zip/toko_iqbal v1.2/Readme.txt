list fitur yang blm ada

penjualan:
- penjualan.php
- detailpenjualan (nyampur di penjualan.php)

admin:
- datapelanggan.php

